/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BALOK;

/**
 *
 * @author pc
 */
import java.util.Scanner;
public class VOLUME_DAN_LUAS_BALOK {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int panjang,lebar, tinggi, luas, volume;
        
        System.out.println("Program Menghitung Luas dan Volume Balok");
        System.out.println("==================================");
        
        System.out.println("Input nilai panjang :");
        panjang = input.nextInt();
        System.out.println("Input nilai lebar :");
        lebar = input.nextInt();
        System.out.println("Input nilai tinggi :");
        tinggi = input.nextInt();
        
        luas = 2* (panjang*lebar)+(panjang*tinggi)+(lebar*tinggi);
        volume = panjang * lebar * tinggi;
      
        System.out.println("luas balok adalah = "+luas+"cm^2");
        System.out.println("volume balok adalah = "+volume+"cm^3");
        
    }
    
}
