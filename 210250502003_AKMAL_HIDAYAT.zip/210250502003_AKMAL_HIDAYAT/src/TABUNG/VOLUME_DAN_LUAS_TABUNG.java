/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TABUNG;

/**
 *
 * @author pc
 */
import java.util.Scanner;
public class VOLUME_DAN_LUAS_TABUNG {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int r,t;
        double phi = 3.14, luas, volume;
     
        System.out.println("Program Menghitung Luas dan Volume Tabung");
        System.out.println("=========================================");
        
        System.out.println("input nilai r : ");
        r = input.nextInt();
        System.out.println("input nilai t : ");
        t = input.nextInt();
        
        luas = 2*phi*r*(r+t);
        volume = phi*Math.pow(r,2)*t;
        
        
        System.out.println("luas tabung adalah = "+luas+"cm^2");
        System.out.println("volume tabung adalah = "+volume+"cm^3");
        
    }
    
}
