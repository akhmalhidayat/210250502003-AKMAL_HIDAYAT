/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KERUCUT;

/**
 *
 * @author pc
 */
import java.util.Scanner;
public class VOLUME_DAN_LUAS_KERUCUT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int t,r,s;
        double phi = 3.14, luas, volume;
        
        System.out.println("Program Menghitung Luas dan volume Kerucut");
        System.out.println("=================================");
        
        
        System.out.println("input nilai tinggi kerucut : ");
        t = input.nextInt();
        System.out.println("input nilai jari jari kerucut : ");
        r = input.nextInt();
        System.out.println("input nilai garis pelukis kerucut : ");
        s = input.nextInt();
        
        luas = (phi*Math.pow(r,2))+(phi*r*s);
        volume = 1*phi*Math.pow(r,2)*t/3;
       
        System.out.println("tinggi kerucut adalah = "+t);
        System.out.println("jari jai kerucut adalah = "+r);
        System.out.println("luas kerucut adalah = "+luas+"cm^2");
        
        System.out.println("tinggi kerucut adalah = "+t);
        System.out.println("jari jari kerucut adalah = "+r);
        System.out.println("garis pelukis kerucut adalah = "+s);
        System.out.println("volume kerucut adalah = "+volume+"cm^3");
                
    }
    
}
