/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BOLA;

/**
 *
 * @author pc
 */
import java.util.Scanner;
public class VOLUME_DAN_LUAS_BOLA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int r;
        double phi = 3.14, luas, volume;
        
        System.out.println("Program menghitung Luas dan Volume Bola");
        System.out.println("=======================================");
        
        
        System.out.println("Input jari jari bola : ");
        r = input.nextInt();
        
        luas = (4*phi*Math.pow(r,2));
        volume = 4*phi*Math.pow(r,3)/3;
        
        
        System.out.println("jari jari bola adalah = "+r+"cm");
        System.out.println("luas bola adalah = "+luas+"cm^2");
        System.out.println("volume bola adalah ="+volume+"cm^3");
    }
    
}
